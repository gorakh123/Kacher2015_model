import numpy as np
from scipy.interpolate import interp1d
from scipy.optimize import fsolve
from numpy.typing import ArrayLike



def number_conc_soot_activated1(
        psi: ArrayLike, 
        EIsoot: float, 
        rho: ArrayLike, 
        Dilution: ArrayLike, 
        N0: float
) -> ArrayLike:
    """Determines the number concentration of activated soot particles in the plume

    Args
    ----
        psi: ArrayLike
            The proportion of activated soot compared to the emitted non activated soot
        EIsoot: float
            The emission index of soot per fuel burned (/kg)
        rho: ArrayLike
            The density of the aerosol (kg/m^3)
        Dilution: ArrayLike
            The dilution parameter of the plume
        N0: float
            air to fuel ratio
    
    Returns
    -------
        ArrayLike:
            The number concentration of activated soot particles in the plume
    
    Notes
    -----
        The Dilution parameter used typically is a function of temperature
    """
    return (psi * Dilution * EIsoot * N0) / rho



def number_conc_ambient_activated1(
        psi: ArrayLike,
        Ta: float,
        T: ArrayLike,
        Dilution: ArrayLike,
        na: float
) -> ArrayLike:
    """Determines the number concentration of activated ambient aerosols in the plume

    Args
    ----
        psi: ArrayLike
            The proportion of activated aerosols compared to the emitted non activated aerosols
        Ta: float
            The ambient temperature (K)
        T: ArrayLike
            The temperature of the plume (K)
        Dilution: ArrayLike
            The dilution parameter of the plume
        na: float
            The number concentration of ambient aerosols (m^-3) already in the atmosphere
    
    Returns
    -------
        ArrayLike:
            The number concentration of activated ambient aerosols in the plume
    """
    return (psi * (Ta/T) * (1 - Dilution) * na)



def b1_param(
        T: ArrayLike, 
        nwSat: ArrayLike, 
        meanSpeed: ArrayLike,
        eSat: ArrayLike,
        smw: ArrayLike
        ) -> ArrayLike:
    """Determines the b1 parameter of the microphysical model

    Args
    ----
        T: ArrayLike
            Temperature (K)
        nwSat: ArrayLike
            Number concentration of H20 at saturation water as a function of temperature (m^-3)
        meanSpeed: ArrayLike
            Mean thermal speed of water molecules as a function of temperature (m/s)
        eSat: ArrayLike
            Saturation vapor pressure of water as a function of temperature (Pa)
        smw: float
            supersaturation ratio of water

    Returns
    -------
        ArrayLike:
            b1 parameter of the microphysical model
    """
    vol = 2.99e-29 # Volume of water molecule (m^3) May need improvement
    return (nwSat * vol * meanSpeed * smw)/4



def tau_activation(avgZeta: float, sw: ArrayLike, dSdT: ArrayLike) -> ArrayLike:
    """Determines the activation timescale of the aerosol

    Args
    ----
        avgZeta: float
            The average size distribution slope parameter of the plume
        sw: ArrayLike
            The supersaturation ratio of the plume along the mixing line
        dSdT: ArrayLike
            The supersaturation forcing term in the microphysical model
    
    Returns
    -------
        ArrayLike:
            The activation timescale of the aerosol
    """
    return (3 * sw) / (2 * avgZeta * dSdT)



def tau_growth(b1: ArrayLike, rActivationAvg: ArrayLike):
    """Determines the growth timescale of the aerosol

    Args
    ----
        b1: ArrayLike
            The b1 parameter of the microphysical model
        rActivationAvg: ArrayLike
            The average activation radius of the plume particles
    
    Returns
    -------
        ArrayLike:
            The growth timescale of the aerosol
    """
    return rActivationAvg / b1



def kw_parameter(tauActivation: ArrayLike, tauGrowth: ArrayLike) -> ArrayLike:
    """Determines the kw parameter of the microphysical model

    Args
    ----
        tauActivation: ArrayLike
            The activation timescale of the aerosol
        tauGrowth: ArrayLike
            The growth timescale of the aerosol
    
    Returns
    -------
        ArrayLike:
            The kw parameter of the microphysical model

    See Also
    --------
        Kacher 2015 for the derivation
    """
    return tauActivation / tauGrowth



def condensation_sink(b1: ArrayLike, rActivation: ArrayLike, nwSaturation: ArrayLike, kw: ArrayLike) -> ArrayLike:
    """Determines the condensation sink of the plume R_w

    Args
    ----
        b1: ArrayLike
            The b1 parameter of the microphysical model
        rActivation: ArrayLike
            The activation radius of the plume particles
        nwSaturation: ArrayLike
            The number concentration of H2O in water saturation
        kw: ArrayLike
            The kw parameter of the microphysical model
    
    Returns
    -------
        ArrayLike:
            The condensation sink of the plume
    
    See Also
    --------
        Kacher 2015 for the derivation
    """
    volH2O = 2.99 * 10**-29 # Volume of water molecule (m^3)
    return ((b1 * 4 * np.pi * rActivation**2) * 
            1 + 2 * kw + 2 * kw**2)/(volH2O * nwSaturation)



def number_conc_all_activated2(dSdT: ArrayLike, condSink: ArrayLike):
    """Determines the number concentration required to quench all the excess water vapour
    
    Args
    ----
        dSdT: ArrayLike
            The supersaturation forcing term in the microphysical model
        condSink: ArrayLike
            The condensation sink of the plume
    
    Returns
    -------
        ArrayLike:
            The number concentration required to quench all the excess water vapour
    """
    return dSdT / condSink



def number_conc_all_activated1(nwSoot: ArrayLike, nwAmbient: ArrayLike) -> ArrayLike:
    """Determines the total number concentration of activated water droplets

    Args
    ----
        nwSoot: ArrayLike
            The number concentration of activated soot particles in the plume (m^-3)
        nwAmbient: ArrayLike
            The number concentration of activated ambient aerosols in the plume (m^-3)
    
    Returns
    -------
        ArrayLike:
            The total number concentration of activated water droplets (m^-3)
    """
    return nwSoot + nwAmbient


def find_ro(rAct: ArrayLike, kW: ArrayLike)-> ArrayLike:
    """Determines the radius of the activated water droplets

    Args
    ----
        rAct: ArrayLike
            The average activation radius of the plume particles
        kW: ArrayLike
            The kw parameter of the microphysical model
    
    Returns
    -------
        ArrayLike:
            The radius of the activated water droplets
    """
    return rAct * (1 + kW)



def find_activated_nw(sw: ArrayLike, nw1: ArrayLike, nw2: ArrayLike)-> ArrayLike:
    """Determines the number concentration of activated water droplets by finding the intercept
       of number_conc_all_activated2 and number_conc_activated

    Args
    ----
        sw: ArrayLike
            The supersaturation ratio of the plume along the mixing line
        nw1: ArrayLike
            The number concentration of activated soot particles in the plume
        nw2: ArrayLike
            The number concentration of activated ambient aerosols in the plume
    
    Returns
    -------
        ArrayLike:
            [1 x 3] array containing the supersaturation ratio, the number concentration of activated water droplets
            and the index of the intercept
    
    Notes
    -----
        Ensure arrays are cleaned, ie no NaNs or Infs and also sw >= 0
    """
    diff = np.array(nw1) - np.array(nw2) 
    
    sign_changes = np.where(np.diff(np.sign(diff)))[0] # Finds the index just before sign of diff changes
    return (sw[sign_changes] + sw[sign_changes+1])/2, (nw1[sign_changes] + nw1[sign_changes+1] + nw2[sign_changes] + nw2[sign_changes+1])/4 , sign_changes



def Phi_function(nwfinal: ArrayLike, nwSoot: ArrayLike, psiSoot: ArrayLike, nwAmbient: ArrayLike, psiAmbient: ArrayLike)-> ArrayLike:
    """Determines the fraction of activated water droplets that are soot

    Args
    ----
        nwfinal: ArrayLike
            The number concentration of activated water droplets
        nwSoot: ArrayLike
            The number concentration of activated soot particles in the plume
        psiSoot: ArrayLike
            The proportion of activated soot compared to the emitted non activated soot
        nwAmbient: ArrayLike
            The number concentration of activated ambient aerosols in the plume
        psiAmbient: ArrayLike
            The proportion of activated aerosols compared to the emitted non activated aerosols
    
    Returns
    -------
        ArrayLike:
            The fraction of activated water droplets that are soot
    """
    nSoot = nwSoot / psiSoot
    nAmbient = nwAmbient / psiAmbient
    return nwfinal / (nSoot + nAmbient)



def optical_depth_function(nwfinal: float, rfinal: float, d0: float, Do: float)-> float:
    """Determines the optical depth of the plume

    Args
    ----
        nwfinal: float
            The number concentration of activated water droplets
        rfinal: float
            The radius of the activated water droplets
        d0: float
            engine diameter
        Do: float
            The dilution parameter at activation relaxation
    
    Returns
    -------
        float:
            The optical depth of the plume
    """
    d = d0 / np.sqrt(Do) # Plume diamter at activation relaxation
    Q = 1 # to be determined
    return np.pi * rfinal**2 * Q * nwfinal * d